These two files need to be located in the same directory.
ie: c:\mIRC\scripts
once that is completed, /load -rs c:\path\to\files\wraith.mrc

Currently the script supports 5.80 and up.

type /helpauth once it is loaded.


-lordares